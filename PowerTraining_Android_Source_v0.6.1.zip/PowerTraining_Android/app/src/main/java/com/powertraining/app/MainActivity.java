package com.powertraining.app;

import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Base64;
import android.view.Window;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

public class MainActivity extends ComponentActivity {
    private WebView webView;
    private ActivityResultLauncher<ScanOptions> barcodeLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(10, 11, 13));
        w.setNavigationBarColor(Color.rgb(10, 11, 13));

        // Register scanner once during Activity creation. This is the recommended
        // Android Activity Result API and avoids the old startActivityForResult flow.
        barcodeLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (webView == null) return;
            if (result != null && result.getContents() != null) {
                String quoted = JSONObject.quote(result.getContents());
                webView.evaluateJavascript("window.onQrScanned(" + quoted + ")", null);
            } else {
                webView.evaluateJavascript("window.onQrScanCancelled && window.onQrScanCancelled()", null);
            }
        });

        webView = new WebView(this);

        // Android 15/16 enforce edge-to-edge for modern targets. Keep app content
        // below the system status bar and add a small visual margin requested for PT.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int statusBar = insets.getSystemWindowInsetTop();
            int extraTop = Math.round(14 * getResources().getDisplayMetrics().density);
            v.setPadding(0, statusBar + extraTop, 0, 0);
            return insets;
        });

        setContentView(webView);
        webView.requestApplyInsets();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.setBackgroundColor(Color.rgb(10, 11, 13));
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void startQrScanner() {
            runOnUiThread(() -> {
                try {
                    ScanOptions options = new ScanOptions();
                    options.setDesiredBarcodeFormats(ScanOptions.QR_CODE);
                    options.setPrompt("Escanea el QR de tu clase");
                    options.setBeepEnabled(false);
                    options.setBarcodeImageEnabled(false);
                    options.setOrientationLocked(false);
                    barcodeLauncher.launch(options);
                } catch (Throwable e) {
                    if (webView != null) {
                        String msg = JSONObject.quote("No se pudo abrir la cámara: " + e.getClass().getSimpleName());
                        webView.evaluateJavascript("window.onQrScanError && window.onQrScanError(" + msg + ")", null);
                    }
                }
            });
        }

        @JavascriptInterface
        public String generateQr(String content) {
            try {
                BarcodeEncoder encoder = new BarcodeEncoder();
                Bitmap bitmap = encoder.encodeBitmap(content, BarcodeFormat.QR_CODE, 800, 800);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
