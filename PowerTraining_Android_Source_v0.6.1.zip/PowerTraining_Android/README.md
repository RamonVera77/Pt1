Power Training Android v0.6 pilot

- Corrige cierre al abrir lector QR usando Activity Result API.
- Mantiene margen superior seguro para barra de estado.
- Mantiene corrección de rol coach y validación QR en servidor.

# Power Training v0.4 Pilot

Versión multiusuario conectada a Supabase.

## Incluye
- Registro e inicio de sesión por correo/contraseña
- Roles: propietario, coach y atleta
- Clases compartidas y editables
- WODs compartidos y editables
- Reservas
- QR dinámico por clase
- Asistencia guardada en la nube
- Captura de resultados por coach
- Historial básico de resultados del atleta
- Modo oscuro/claro

## Códigos temporales del piloto
- Enrique / propietario: `PT-ENRIQUE-7K4M`
- Coach: `PT-COACH-9Q2X`
- Atleta: no necesita código

Estos códigos son solo para la prueba y deben eliminarse antes de producción.


## v0.4
- Corrección de asignación de rol piloto para propietario/coach.
- Reservas visibles y cancelables por atleta.
- Check-in QR validado por el servidor de Supabase.


## v0.5 pilot
- Corrige el espacio superior para que la interfaz no se empalme con la hora, Wi‑Fi o batería en Android 15.
- Aplica el código de rol antes de cargar la pantalla principal para evitar que un coach aparezca primero como atleta.
