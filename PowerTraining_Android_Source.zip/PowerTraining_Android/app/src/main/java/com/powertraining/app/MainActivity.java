package com.powertraining.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class MainActivity extends ComponentActivity {
    private WebView webView;
    private FrameLayout root;
    private ActivityResultLauncher<ScanOptions> barcodeLauncher;
    private ActivityResultLauncher<Intent> fileChooserLauncher;
    private ActivityResultLauncher<String> cameraPermissionLauncher;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraPhotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        WindowCompat.setDecorFitsSystemWindows(w, false);
        w.setStatusBarColor(Color.rgb(10, 11, 13));
        w.setNavigationBarColor(Color.rgb(10, 11, 13));

        barcodeLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (webView == null) return;
            if (result != null && result.getContents() != null) {
                String quoted = JSONObject.quote(result.getContents());
                webView.evaluateJavascript("window.onQrScanned(" + quoted + ")", null);
            } else {
                webView.evaluateJavascript("window.onQrScanCancelled && window.onQrScanCancelled()", null);
            }
        });

        cameraPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            launchPhotoChooser(granted);
        });

        fileChooserLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] uris = null;
            if (result.getResultCode() == Activity.RESULT_OK) {
                Intent data = result.getData();
                if (data == null || data.getData() == null) {
                    if (cameraPhotoUri != null) uris = new Uri[]{cameraPhotoUri};
                } else {
                    ClipData clipData = data.getClipData();
                    if (clipData != null) {
                        uris = new Uri[clipData.getItemCount()];
                        for (int i = 0; i < clipData.getItemCount(); i++) {
                            uris[i] = clipData.getItemAt(i).getUri();
                        }
                    } else {
                        uris = new Uri[]{data.getData()};
                    }
                }
            }
            filePathCallback.onReceiveValue(uris);
            filePathCallback = null;
            cameraPhotoUri = null;
        });

        root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);

        // Android 15/16 draw apps edge-to-edge by default. Instead of guessing
        // margins in HTML, physically resize the WebView to the safe rectangle
        // between the status/cutout area and the Android navigation area.
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() |
                    WindowInsetsCompat.Type.displayCutout()
            );
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) webView.getLayoutParams();
            lp.setMargins(bars.left, bars.top, bars.right, bars.bottom);
            webView.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.requestApplyInsets(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                boolean cameraGranted = ContextCompat.checkSelfPermission(
                        MainActivity.this, Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED;
                if (cameraGranted) {
                    launchPhotoChooser(true);
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
                }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.setBackgroundColor(Color.rgb(10, 11, 13));
        webView.loadUrl("file:///android_asset/index.html");
    }


    private void launchPhotoChooser(boolean includeCamera) {
        if (filePathCallback == null) return;
        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.addCategory(Intent.CATEGORY_OPENABLE);
        galleryIntent.setType("image/*");

        Intent cameraIntent = null;
        if (includeCamera) {
            try {
                File photo = File.createTempFile("power_training_profile_", ".jpg", getCacheDir());
                cameraPhotoUri = FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", photo
                );
                cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri);
                cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if (cameraIntent.resolveActivity(getPackageManager()) == null) cameraIntent = null;
            } catch (Exception ignored) {
                cameraPhotoUri = null;
            }
        }

        Intent chooser = Intent.createChooser(galleryIntent, "Foto de perfil");
        if (cameraIntent != null) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        }
        try {
            fileChooserLauncher.launch(chooser);
        } catch (Exception e) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
            cameraPhotoUri = null;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void startQrScanner() {
            runOnUiThread(() -> {
                try {
                    ScanOptions options = new ScanOptions();
                    options.setDesiredBarcodeFormats(ScanOptions.QR_CODE);
                    options.setPrompt("Escanea el QR de tu clase");
                    options.setBeepEnabled(false);
                    options.setBarcodeImageEnabled(false);
                    options.setOrientationLocked(false);
                    barcodeLauncher.launch(options);
                } catch (Throwable e) {
                    if (webView != null) {
                        String msg = JSONObject.quote("No se pudo abrir la cámara: " + e.getClass().getSimpleName());
                        webView.evaluateJavascript("window.onQrScanError && window.onQrScanError(" + msg + ")", null);
                    }
                }
            });
        }

        @JavascriptInterface
        public void playFanfare() {
            runOnUiThread(() -> {
                final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 90);
                final Handler h = new Handler(Looper.getMainLooper());
                h.post(() -> tone.startTone(ToneGenerator.TONE_DTMF_3, 120));
                h.postDelayed(() -> tone.startTone(ToneGenerator.TONE_DTMF_6, 140), 150);
                h.postDelayed(() -> tone.startTone(ToneGenerator.TONE_DTMF_9, 180), 320);
                h.postDelayed(() -> tone.startTone(ToneGenerator.TONE_PROP_ACK, 420), 520);
                h.postDelayed(tone::release, 1050);
            });
        }

        @JavascriptInterface
        public void playBoo() {
            runOnUiThread(() -> {
                final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 82);
                final Handler h = new Handler(Looper.getMainLooper());
                h.post(() -> tone.startTone(ToneGenerator.TONE_DTMF_2, 480));
                h.postDelayed(() -> tone.startTone(ToneGenerator.TONE_DTMF_1, 650), 420);
                h.postDelayed(tone::release, 1200);
            });
        }

        @JavascriptInterface
        public String generateQr(String content) {
            try {
                BarcodeEncoder encoder = new BarcodeEncoder();
                Bitmap bitmap = encoder.encodeBitmap(content, BarcodeFormat.QR_CODE, 800, 800);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
