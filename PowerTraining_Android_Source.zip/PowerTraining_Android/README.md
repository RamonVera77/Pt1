# Power Training Android demo v0.2

Demo Android instalable de Power Training.

## Incluye
- Registro local en el dispositivo.
- Roles Atleta, Coach y Propietario/Admin.
- Clases, WOD, progreso y perfil.
- Captura de resultados por coach.
- Modo oscuro/claro.
- Branding Power Training dorado.
- **Asistencia por QR dinámico**: el coach muestra un código que rota cada 30 segundos y el atleta lo escanea desde Inicio.
- Validación local del QR, vigencia y prevención de duplicados en la demo.

> Para producción, la validación de asistencia se llevará al backend para que no dependa del reloj ni del almacenamiento del teléfono.
