# Power Training Android demo

Demo Android instalable que envuelve la demo web local en un WebView nativo.

## Incluye
- Registro local en el dispositivo.
- Roles Atleta, Coach y Propietario/Admin.
- Clases, WOD, progreso y perfil.
- Captura de resultados por coach.
- Modo oscuro/claro.
- Branding Power Training dorado.

## Compilación automática
El workflow `.github/workflows/build-apk.yml` genera `PowerTraining-Demo.apk` como artifact descargable.
