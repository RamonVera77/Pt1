# Power Training Android — v0.7 pilot

Pilot Android shell for Power Training.

Included in v0.7:
- Native QR attendance scanner.
- Attendance window: 30 minutes before to 15 minutes after class start.
- Punctuality fanfare and late-arrival "Buuu" message.
- Android safe-area handling that physically keeps the WebView above system bars.
- Profile photos from camera/gallery and profile gender category.
- WOD builder with selectable exercise chips and 5.0–10.0 difficulty.
- Coach result capture with structured numeric result types.
- Coach thumbs-up recognition per class.
- Monthly Honor Board: men, women, and effort Top 10.
- Light/dark theme.

Backend: Supabase project PowerTrainingApp.
This is a pilot/debug build, not the final signed Play Store release.
